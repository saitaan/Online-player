package com.cleanplayer.app

import okhttp3.Headers
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.RequestBody.Companion.toRequestBody
import org.schabi.newpipe.extractor.NewPipe
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.downloader.Downloader
import org.schabi.newpipe.extractor.downloader.Request
import org.schabi.newpipe.extractor.downloader.Response
import org.schabi.newpipe.extractor.stream.AudioStream
import org.schabi.newpipe.extractor.stream.StreamInfo
import org.schabi.newpipe.extractor.stream.VideoStream
import java.io.IOException
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

data class ResolvedVideoQuality(
    val qualityLabel: String,
    val resolution: Int,
    val videoUrl: String,
    val audioUrl: String?
)

data class ResolvedYouTubeStream(
    val videoUrl: String,
    val audioUrl: String?,
    val availableQualities: List<ResolvedVideoQuality>
)

/**
 * NewPipe Extractor 0.26.x bridge.
 *
 * NewPipe Extractor deliberately does not ship an Android HTTP client.  The
 * downloader below adapts the extractor's Request/Response contract to the
 * app's existing OkHttp dependency, so all extractor requests share the same
 * user agent, redirects and timeouts.
 */
object YouTubeStreamResolver {

    private const val YOUTUBE_WATCH_URL = "https://www.youtube.com/watch?v="
    private const val USER_AGENT =
        "Mozilla/5.0 (Linux; Android 14; Pixel 7) AppleWebKit/537.36 " +
            "(KHTML, like Gecko) Chrome/128.0.0.0 Mobile Safari/537.36"

    private val executor = Executors.newFixedThreadPool(3)
    private val initialized = AtomicBoolean(false)
    private val client = OkHttpClient.Builder()
        .followRedirects(true)
        .followSslRedirects(true)
        .retryOnConnectionFailure(true)
        .connectTimeout(20, java.util.concurrent.TimeUnit.SECONDS)
        .readTimeout(30, java.util.concurrent.TimeUnit.SECONDS)
        .build()

    @Synchronized
    fun initNewPipe() {
        if (initialized.get()) return
        if (NewPipe.getDownloader() == null) {
            NewPipe.init(OkHttpNewPipeDownloader)
        }
        initialized.set(true)
    }

    fun resolveStreams(videoId: String, callback: (ResolvedYouTubeStream?) -> Unit) {
        executor.execute {
            val resolved = try {
                initNewPipe()
                val service = NewPipe.getService(ServiceList.YouTube.id)
                val info = StreamInfo.getInfo(service, "$YOUTUBE_WATCH_URL$videoId")
                buildResolvedStream(info)
            } catch (error: Throwable) {
                error.printStackTrace()
                null
            }

            android.os.Handler(android.os.Looper.getMainLooper()).post {
                callback(resolved)
            }
        }
    }

    private fun buildResolvedStream(info: StreamInfo): ResolvedYouTubeStream? {
        val audioUrl = info.audioStreams
            .asSequence()
            .filter { it.url.isNotBlank() }
            .maxWithOrNull(
                compareBy<AudioStream> { it.averageBitrate }
                    .thenBy { it.bitrate }
            )
            ?.url

        val videoStreams = (info.videoStreams + info.videoOnlyStreams)
            .asSequence()
            .filter { it.url.isNotBlank() }
            .distinctBy { it.url }
            .toList()

        if (videoStreams.isEmpty()) return null

        val qualities = videoStreams
            .map { stream ->
                ResolvedVideoQuality(
                    qualityLabel = stream.quality.ifBlank { stream.resolution.ifBlank { "Auto" } },
                    resolution = stream.height.takeIf { it > 0 } ?: parseResolution(stream.resolution),
                    videoUrl = stream.url,
                    audioUrl = if (stream.isVideoOnly) audioUrl else null
                )
            }
            .sortedWith(
                compareByDescending<ResolvedVideoQuality> { it.resolution }
                    .thenByDescending { it.qualityLabel }
            )

        val selected = qualities.firstOrNull { it.audioUrl != null } ?: qualities.first()
        return ResolvedYouTubeStream(
            videoUrl = selected.videoUrl,
            audioUrl = selected.audioUrl,
            availableQualities = qualities
        )
    }

    private fun parseResolution(resolution: String): Int {
        return Regex("(\\d+)").find(resolution)?.groupValues?.get(1)?.toIntOrNull() ?: 0
    }

    private object OkHttpNewPipeDownloader : Downloader() {
        override fun execute(request: Request): Response {
            val headersBuilder = Headers.Builder()
            request.headers().forEach { (name, values) ->
                values.forEach { value -> headersBuilder.add(name, value) }
            }
            if (request.headers().keys.none { it.equals("User-Agent", ignoreCase = true) }) {
                headersBuilder.add("User-Agent", USER_AGENT)
            }

            val body = request.dataToSend()?.toRequestBody(
                "application/octet-stream".toMediaType()
            )
            val httpRequest = okhttp3.Request.Builder()
                .url(request.url())
                .headers(headersBuilder.build())
                .method(request.httpMethod(), body)
                .build()

            client.newCall(httpRequest).execute().use { response ->
                return Response(
                    response.code,
                    response.message,
                    response.headers.toMultimap(),
                    response.body?.string().orEmpty(),
                    response.request.url.toString()
                )
            }
        }
    }
}