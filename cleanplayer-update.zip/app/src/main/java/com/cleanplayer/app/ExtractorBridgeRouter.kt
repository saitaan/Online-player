package com.cleanplayer.app

import android.content.Context

/**
 * Keeps the extractor selector in the existing settings UI.
 *
 * NewPipe is the only in-process extractor shipped by this build.  The other
 * labels are retained as preferences so old settings do not crash the app.
 */
object ExtractorBridgeRouter {
    const val ENGINE_AUTO = "AUTO"
    const val ENGINE_INNERTUBE = "INNERTUBE"
    const val ENGINE_NEWPIPE = "NEWPIPE"
    const val ENGINE_PIPED = "PIPED"
    const val ENGINE_INVIDIOUS = "INVIDIOUS"

    private const val PREFS = "cleanplayer_yt_prefs"
    private const val KEY_ENGINE = "pref_extractor_engine"

    fun getActiveEngineId(context: Context): String {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_ENGINE, ENGINE_AUTO) ?: ENGINE_AUTO
    }

    fun setActiveEngine(context: Context, engineId: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_ENGINE, engineId)
            .apply()
    }

    fun getActiveEngineName(context: Context): String {
        return when (getActiveEngineId(context)) {
            ENGINE_NEWPIPE -> "NewPipe Extractor 0.26.5"
            ENGINE_INNERTUBE -> "Direct InnerTube (compatibility mode)"
            ENGINE_PIPED -> "Piped (not configured)"
            ENGINE_INVIDIOUS -> "Invidious (not configured)"
            else -> "NewPipe Extractor 0.26.5 (Auto)"
        }
    }
}