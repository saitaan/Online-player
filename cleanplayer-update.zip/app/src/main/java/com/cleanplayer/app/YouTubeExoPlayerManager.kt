package com.cleanplayer.app

import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.source.MergingMediaSource
import androidx.media3.exoplayer.source.ProgressiveMediaSource
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import androidx.media3.ui.PlayerView

/**
 * AndroidX Media3 (ExoPlayer) Dedicated Adaptive Engine for YouTube
 * Supports high-definition MergingMediaSource (Separate Video + Separate Audio stream synchronization).
 * Thread-safe, synchronized playback manager with null-safety and robust lifecycle controls.
 */
object YouTubeExoPlayerManager {

    var exoPlayer: ExoPlayer? = null
        private set

    var currentPlayingVideo: YouTubeVideo? = null
        private set

    var currentStreamUrl: String? = null
        private set

    var currentQualityLabel: String = "Auto"
        private set

    private var trackSelector: DefaultTrackSelector? = null
    private val mainHandler = Handler(Looper.getMainLooper())
    private var sponsorCheckRunnable: Runnable? = null
    private val playerLock = Any()

    var onSponsorSkipped: ((category: String) -> Unit)? = null
    var onPlaybackStateChanged: ((isPlaying: Boolean) -> Unit)? = null
    var onBufferingStateChanged: ((isBuffering: Boolean) -> Unit)? = null
    var onPlayerError: ((error: PlaybackException) -> Unit)? = null
    var onAudioSessionIdChanged: ((sessionId: Int) -> Unit)? = null

    @Synchronized
    fun getOrCreatePlayer(context: Context): ExoPlayer {
        val existing = exoPlayer
        if (existing != null) return existing

        val appContext = context.applicationContext
        val selector = DefaultTrackSelector(appContext)
        trackSelector = selector

        val httpDataSourceFactory = DefaultHttpDataSource.Factory()
            .setUserAgent("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36")
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(15000)
            .setReadTimeoutMs(15000)

        val dataSourceFactory = DefaultDataSource.Factory(appContext, httpDataSourceFactory)
        val mediaSourceFactory = DefaultMediaSourceFactory(dataSourceFactory)

        val loadControl = DefaultLoadControl.Builder()
            .setBufferDurationsMs(
                DefaultLoadControl.DEFAULT_MIN_BUFFER_MS,
                DefaultLoadControl.DEFAULT_MAX_BUFFER_MS,
                1500, // min buffer for playback
                2500  // min buffer for playback after rebuffer
            )
            .build()

        val audioAttributes = AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA)
            .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
            .build()

        val player = ExoPlayer.Builder(appContext)
            .setMediaSourceFactory(mediaSourceFactory)
            .setTrackSelector(selector)
            .setLoadControl(loadControl)
            .setAudioAttributes(audioAttributes, true)
            .setHandleAudioBecomingNoisy(true)
            .build()

        player.addListener(object : Player.Listener {
            override fun onAudioSessionIdChanged(audioSessionId: Int) {
                if (audioSessionId > 0) {
                    onAudioSessionIdChanged?.invoke(audioSessionId)
                }
            }

            override fun onIsPlayingChanged(isPlaying: Boolean) {
                onPlaybackStateChanged?.invoke(isPlaying)
                if (isPlaying) {
                    startSponsorCheckLoop()
                } else {
                    stopSponsorCheckLoop()
                }
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                when (playbackState) {
                    Player.STATE_BUFFERING -> {
                        onBufferingStateChanged?.invoke(true)
                    }
                    Player.STATE_READY -> {
                        onBufferingStateChanged?.invoke(false)
                    }
                    Player.STATE_ENDED -> {
                        stopSponsorCheckLoop()
                        onBufferingStateChanged?.invoke(false)
                        onPlaybackStateChanged?.invoke(false)
                    }
                    Player.STATE_IDLE -> {
                        onBufferingStateChanged?.invoke(false)
                    }
                }
            }

            override fun onPlayerError(error: PlaybackException) {
                error.printStackTrace()
                onBufferingStateChanged?.invoke(false)
                onPlaybackStateChanged?.invoke(false)
                onPlayerError?.invoke(error)
            }
        })

        exoPlayer = player
        return player
    }

    @Synchronized
    fun playVideo(
        context: Context,
        video: YouTubeVideo,
        videoStreamUrl: String,
        audioStreamUrl: String? = null,
        isDash: Boolean = false,
        isHls: Boolean = false,
        startPosMs: Long = 0L
    ) {
        val player = getOrCreatePlayer(context)
        val appContext = context.applicationContext
        currentPlayingVideo = video
        currentStreamUrl = videoStreamUrl

        val metadata = MediaMetadata.Builder()
            .setTitle(video.title)
            .setArtist(video.channelTitle)
            .setArtworkUri(Uri.parse(video.thumbnailUrl))
            .build()

        val httpDataSourceFactory = DefaultHttpDataSource.Factory()
            .setUserAgent("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36")
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(15000)
            .setReadTimeoutMs(15000)

        val dataSourceFactory = DefaultDataSource.Factory(appContext, httpDataSourceFactory)

        // Fetch SponsorBlock segments
        SponsorBlockManager.fetchSegments(video.id)

        try {
            onBufferingStateChanged?.invoke(true)

            if (!audioStreamUrl.isNullOrBlank() && audioStreamUrl != videoStreamUrl) {
                // MergingMediaSource for synchronized 1080p+ video and high-bitrate audio
                val videoMediaItem = MediaItem.Builder()
                    .setUri(Uri.parse(videoStreamUrl))
                    .setMediaMetadata(metadata)
                    .build()

                val audioMediaItem = MediaItem.Builder()
                    .setUri(Uri.parse(audioStreamUrl))
                    .build()

                val progressiveFactory = ProgressiveMediaSource.Factory(dataSourceFactory)
                val videoSource = progressiveFactory.createMediaSource(videoMediaItem)
                val audioSource = progressiveFactory.createMediaSource(audioMediaItem)
                val mergedSource = MergingMediaSource(videoSource, audioSource)

                player.setMediaSource(mergedSource)
            } else {
                val mimeType = when {
                    isDash || videoStreamUrl.contains(".mpd") -> MimeTypes.APPLICATION_MPD
                    isHls || videoStreamUrl.contains(".m3u8") -> MimeTypes.APPLICATION_M3U8
                    videoStreamUrl.contains(".webm") -> MimeTypes.VIDEO_WEBM
                    videoStreamUrl.contains(".mp4") -> MimeTypes.VIDEO_MP4
                    else -> null
                }

                val mediaItemBuilder = MediaItem.Builder()
                    .setUri(Uri.parse(videoStreamUrl))
                    .setMediaMetadata(metadata)

                if (mimeType != null) {
                    mediaItemBuilder.setMimeType(mimeType)
                }

                val mediaItem = mediaItemBuilder.build()
                player.setMediaItem(mediaItem)
            }

            player.prepare()
            if (startPosMs > 0L) {
                player.seekTo(startPosMs)
            }
            player.playWhenReady = true
            player.play()

            if (PlayerHolder.backgroundPipMode > 0) {
                MediaPlaybackService.start(
                    context = context,
                    title = video.title,
                    artist = video.channelTitle,
                    isPlaying = true,
                    isYouTube = true,
                    thumbUrl = video.thumbnailUrl
                )
            }
        } catch (e: Exception) {
            e.printStackTrace()
            onBufferingStateChanged?.invoke(false)
        }
    }

    fun playVideo(
        context: Context,
        video: YouTubeVideo,
        streamUrl: String,
        isDash: Boolean = false,
        isHls: Boolean = false,
        startPosMs: Long = 0L
    ) {
        playVideo(context, video, streamUrl, null, isDash, isHls, startPosMs)
    }

    fun attachPlayerView(playerView: PlayerView) {
        val player = getOrCreatePlayer(playerView.context)
        if (playerView.player != player) {
            playerView.player = player
        }
    }

    fun detachPlayerView(playerView: PlayerView) {
        if (playerView.player == exoPlayer) {
            playerView.player = null
        }
    }

    fun togglePlayPause() {
        val player = exoPlayer ?: return
        try {
            if (player.isPlaying) {
                player.pause()
            } else {
                player.play()
            }
        } catch (e: Exception) {}
    }

    fun pause() {
        try {
            exoPlayer?.pause()
        } catch (e: Exception) {}
    }

    fun play() {
        try {
            exoPlayer?.play()
        } catch (e: Exception) {}
    }

    fun seekTo(posMs: Long) {
        try {
            exoPlayer?.seekTo(posMs)
        } catch (e: Exception) {}
    }

    fun setPlaybackSpeed(speed: Float) {
        try {
            exoPlayer?.playbackParameters = PlaybackParameters(speed)
        } catch (e: Exception) {}
    }

    fun setVideoQuality(maxHeight: Int) {
        val selector = trackSelector ?: return
        try {
            if (maxHeight <= 0) {
                selector.parameters = selector.buildUponParameters()
                    .clearVideoSizeConstraints()
                    .build()
                currentQualityLabel = "Auto"
            } else {
                selector.parameters = selector.buildUponParameters()
                    .setMaxVideoSize(3840, maxHeight)
                    .build()
                currentQualityLabel = "${maxHeight}p"
            }
        } catch (e: Exception) {}
    }

    @Synchronized
    private fun startSponsorCheckLoop() {
        stopSponsorCheckLoop()
        val runnable = object : Runnable {
            override fun run() {
                synchronized(playerLock) {
                    val player = exoPlayer
                    if (player != null && player.playbackState != Player.STATE_IDLE && player.playbackState != Player.STATE_ENDED) {
                        try {
                            if (player.isPlaying) {
                                val currentPos = player.currentPosition
                                val skip = SponsorBlockManager.checkSkip(currentPos)
                                if (skip != null) {
                                    player.seekTo(skip.first)
                                    onSponsorSkipped?.invoke(skip.second)
                                }
                            }
                        } catch (e: Exception) {}
                        mainHandler.postDelayed(this, 250)
                    }
                }
            }
        }
        sponsorCheckRunnable = runnable
        mainHandler.postDelayed(runnable, 250)
    }

    @Synchronized
    private fun stopSponsorCheckLoop() {
        sponsorCheckRunnable?.let {
            mainHandler.removeCallbacks(it)
            sponsorCheckRunnable = null
        }
    }

    @Synchronized
    fun release() {
        stopSponsorCheckLoop()
        synchronized(playerLock) {
            try {
                exoPlayer?.stop()
                exoPlayer?.release()
            } catch (e: Exception) {}
            exoPlayer = null
            trackSelector = null
            currentPlayingVideo = null
            currentStreamUrl = null
            onPlaybackStateChanged = null
            onBufferingStateChanged = null
            onSponsorSkipped = null
            onPlayerError = null
        }
    }
}
