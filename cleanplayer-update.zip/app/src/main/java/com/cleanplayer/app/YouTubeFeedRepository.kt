package com.cleanplayer.app

import android.content.Context
import android.os.Handler
import android.os.Looper
import org.schabi.newpipe.extractor.NewPipe
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.kiosk.KioskInfo
import org.schabi.newpipe.extractor.stream.StreamInfoItem
import java.util.concurrent.Executors

data class VideoStreamFormat(
    val qualityLabel: String,
    val resolution: Int,
    val url: String,
    val audioUrl: String? = null
)

object YouTubeFeedRepository {

    private val executor = Executors.newFixedThreadPool(4)
    private val mainHandler = Handler(Looper.getMainLooper())

    val defaultFeed = listOf(
        YouTubeVideo(
            id = "aqz-KE-bpKQ",
            title = "Big Buck Bunny - Official 4K 60FPS Animation Showcase",
            channelTitle = "Blender Studio",
            channelAvatarUrl = "https://i.ytimg.com/vi/aqz-KE-bpKQ/hqdefault.jpg",
            thumbnailUrl = "https://i.ytimg.com/vi/aqz-KE-bpKQ/maxresdefault.jpg",
            duration = "10:34",
            views = "18.5M views",
            uploadDate = "Curated HD",
            streamUrl = null,
            description = "High-definition open animation classic showcase with full multi-stream audio and visual rendering.",
            category = "Animation",
            likes = "450K",
            commentsCount = "12.4K"
        ),
        YouTubeVideo(
            id = "eRsGyueVLvQ",
            title = "Sintel - 4K High Definition Open Movie Experience",
            channelTitle = "Blender Foundation",
            channelAvatarUrl = "https://i.ytimg.com/vi/eRsGyueVLvQ/hqdefault.jpg",
            thumbnailUrl = "https://i.ytimg.com/vi/eRsGyueVLvQ/maxresdefault.jpg",
            duration = "14:48",
            views = "12.2M views",
            uploadDate = "Staff Pick",
            streamUrl = null,
            description = "Epic open-source computer graphics fantasy film with rich spatial acoustics.",
            category = "Film",
            likes = "380K",
            commentsCount = "15.1K"
        ),
        YouTubeVideo(
            id = "R6MlUcmgnt8",
            title = "Tears of Steel - Sci-Fi VFX Open Source Feature Film (4K)",
            channelTitle = "Blender Animation",
            channelAvatarUrl = "https://i.ytimg.com/vi/R6MlUcmgnt8/hqdefault.jpg",
            thumbnailUrl = "https://i.ytimg.com/vi/R6MlUcmgnt8/maxresdefault.jpg",
            duration = "12:14",
            views = "8.4M views",
            uploadDate = "Recommended",
            streamUrl = null,
            description = "Explore futuristic visual effects and robotic mechanics rendered in real-time.",
            category = "Sci-Fi",
            likes = "195K",
            commentsCount = "7.8K"
        ),
        YouTubeVideo(
            id = "whgHPnanPgo",
            title = "Spring - Award-Winning 4K Animated Open Feature",
            channelTitle = "Blender Studio",
            channelAvatarUrl = "https://i.ytimg.com/vi/whgHPnanPgo/hqdefault.jpg",
            thumbnailUrl = "https://i.ytimg.com/vi/whgHPnanPgo/maxresdefault.jpg",
            duration = "07:44",
            views = "9.1M views",
            uploadDate = "Trending",
            streamUrl = null,
            description = "A poetic short film celebrating ancient forest spirits and seasonal balance.",
            category = "Animation",
            likes = "215K",
            commentsCount = "8.2K"
        ),
        YouTubeVideo(
            id = "21X5lGlDOfg",
            title = "NASA Earth from Orbit - High Definition ISS Views (4K HDR)",
            channelTitle = "NASA Official",
            channelAvatarUrl = "https://i.ytimg.com/vi/21X5lGlDOfg/hqdefault.jpg",
            thumbnailUrl = "https://i.ytimg.com/vi/21X5lGlDOfg/maxresdefault.jpg",
            duration = "LIVE",
            views = "92K watching",
            uploadDate = "Streaming",
            streamUrl = null,
            description = "Live views of Earth from the International Space Station exterior cameras.",
            category = "Live",
            likes = "94K",
            commentsCount = "2.6K"
        ),
        YouTubeVideo(
            id = "Y-rmzh0PI3c",
            title = "Cosmos Laundromat - First Cycle 4K Animated Masterpiece",
            channelTitle = "Blender Foundation",
            channelAvatarUrl = "https://i.ytimg.com/vi/Y-rmzh0PI3c/hqdefault.jpg",
            thumbnailUrl = "https://i.ytimg.com/vi/Y-rmzh0PI3c/maxresdefault.jpg",
            duration = "12:10",
            views = "5.7M views",
            uploadDate = "Featured",
            streamUrl = null,
            description = "Absurdist sci-fi fantasy exploring multiverses with expressive character modeling.",
            category = "Trending",
            likes = "128K",
            commentsCount = "4.1K"
        )
    )

    val defaultShorts = listOf(
        YouTubeVideo(
            id = "whgHPnanPgo",
            title = "Ancient Forest Spirits Awaken (Spring 4K)",
            channelTitle = "Blender Studio",
            thumbnailUrl = "https://i.ytimg.com/vi/whgHPnanPgo/hqdefault.jpg",
            duration = "00:58",
            views = "1.2M views",
            uploadDate = "Today",
            category = "Shorts",
            isShort = true
        ),
        YouTubeVideo(
            id = "aqz-KE-bpKQ",
            title = "Big Buck Bunny Forest Chase Highlights",
            channelTitle = "Blender Studio",
            thumbnailUrl = "https://i.ytimg.com/vi/aqz-KE-bpKQ/hqdefault.jpg",
            duration = "00:45",
            views = "850K views",
            uploadDate = "1 day ago",
            category = "Shorts",
            isShort = true
        ),
        YouTubeVideo(
            id = "R6MlUcmgnt8",
            title = "Futuristic VFX Robot Combat Sequence",
            channelTitle = "Blender Animation",
            thumbnailUrl = "https://i.ytimg.com/vi/R6MlUcmgnt8/hqdefault.jpg",
            duration = "00:50",
            views = "4.5M views",
            uploadDate = "3 days ago",
            category = "Shorts",
            isShort = true
        ),
        YouTubeVideo(
            id = "eRsGyueVLvQ",
            title = "Sintel Dragon Flying Cinematic Shot",
            channelTitle = "Blender Foundation",
            thumbnailUrl = "https://i.ytimg.com/vi/eRsGyueVLvQ/hqdefault.jpg",
            duration = "00:35",
            views = "2.1M views",
            uploadDate = "5 days ago",
            category = "Shorts",
            isShort = true
        ),
        YouTubeVideo(
            id = "Y-rmzh0PI3c",
            title = "Cosmos Laundromat Surreal Intro",
            channelTitle = "Blender Foundation",
            thumbnailUrl = "https://i.ytimg.com/vi/Y-rmzh0PI3c/hqdefault.jpg",
            duration = "00:42",
            views = "3.7M views",
            uploadDate = "1 week ago",
            category = "Shorts",
            isShort = true
        ),
        YouTubeVideo(
            id = "21X5lGlDOfg",
            title = "Orbiting Sunrise Over Pacific Ocean",
            channelTitle = "NASA Official",
            thumbnailUrl = "https://i.ytimg.com/vi/21X5lGlDOfg/hqdefault.jpg",
            duration = "00:29",
            views = "420K views",
            uploadDate = "2 weeks ago",
            category = "Shorts",
            isShort = true
        )
    )

    fun getFeed(category: String, callback: (List<YouTubeVideo>) -> Unit) {
        executor.execute {
            var onlineVideos: List<YouTubeVideo>? = null
            try {
                YouTubeStreamResolver.initNewPipe()
                val service = NewPipe.getService(ServiceList.YouTube.id)
                if (category.equals("All", ignoreCase = true)) {
                    val kiosk = KioskInfo.getInfo(service, "https://www.youtube.com/feed/trending")
                    val streamItems = kiosk.relatedItems.filterIsInstance<StreamInfoItem>()
                    if (streamItems.isNotEmpty()) {
                        onlineVideos = streamItems.map { item ->
                            val vId = item.url.substringAfter("v=").substringBefore("&")
                            val lengthSec = item.duration.toInt()
                            val durStr = if (lengthSec > 0) String.format("%02d:%02d", lengthSec / 60, lengthSec % 60) else "00:00"
                            val viewCount = item.viewCount
                            val viewStr = if (viewCount > 1_000_000) String.format("%.1fM views", viewCount / 1_000_000.0) else "$viewCount views"
                            YouTubeVideo(
                                id = vId,
                                title = item.name ?: "",
                                channelTitle = item.uploaderName ?: "",
                                channelAvatarUrl = item.uploaderAvatarUrl,
                                thumbnailUrl = item.thumbnailUrl ?: "https://i.ytimg.com/vi/$vId/hqdefault.jpg",
                                duration = durStr,
                                views = viewStr,
                                uploadDate = item.textualUploadDate ?: "Trending",
                                category = category
                            )
                        }
                    }
                } else {
                    val searchExtractor = service.getSearchExtractor(category, listOf("videos"), "")
                    searchExtractor.fetchPage()
                    val streamItems = searchExtractor.initialPage.items.filterIsInstance<StreamInfoItem>()
                    if (streamItems.isNotEmpty()) {
                        onlineVideos = streamItems.map { item ->
                            val vId = item.url.substringAfter("v=").substringBefore("&")
                            val lengthSec = item.duration.toInt()
                            val durStr = if (lengthSec > 0) String.format("%02d:%02d", lengthSec / 60, lengthSec % 60) else "00:00"
                            val viewCount = item.viewCount
                            val viewStr = if (viewCount > 1_000_000) String.format("%.1fM views", viewCount / 1_000_000.0) else "$viewCount views"
                            YouTubeVideo(
                                id = vId,
                                title = item.name ?: "",
                                channelTitle = item.uploaderName ?: "",
                                channelAvatarUrl = item.uploaderAvatarUrl,
                                thumbnailUrl = item.thumbnailUrl ?: "https://i.ytimg.com/vi/$vId/hqdefault.jpg",
                                duration = durStr,
                                views = viewStr,
                                uploadDate = item.textualUploadDate ?: "Category",
                                category = category
                            )
                        }
                    }
                }
            } catch (e: Exception) {
                // Fallback to defaultFeed
            }

            val finalResult = if (!onlineVideos.isNullOrEmpty()) {
                onlineVideos
            } else {
                if (category.equals("All", ignoreCase = true)) {
                    defaultFeed
                } else {
                    val filtered = defaultFeed.filter { it.category.equals(category, ignoreCase = true) }
                    if (filtered.isNotEmpty()) filtered else defaultFeed
                }
            }
            mainHandler.post { callback(finalResult) }
        }
    }

    fun searchVideos(query: String, callback: (List<YouTubeVideo>) -> Unit) {
        executor.execute {
            var onlineVideos: List<YouTubeVideo>? = null
            try {
                YouTubeStreamResolver.initNewPipe()
                val service = NewPipe.getService(ServiceList.YouTube.id)
                val searchExtractor = service.getSearchExtractor(query, listOf("videos"), "")
                searchExtractor.fetchPage()
                val streamItems = searchExtractor.initialPage.items.filterIsInstance<StreamInfoItem>()
                if (streamItems.isNotEmpty()) {
                    onlineVideos = streamItems.map { item ->
                        val vId = item.url.substringAfter("v=").substringBefore("&")
                        val lengthSec = item.duration.toInt()
                        val durStr = if (lengthSec > 0) String.format("%02d:%02d", lengthSec / 60, lengthSec % 60) else "00:00"
                        val viewCount = item.viewCount
                        val viewStr = if (viewCount > 1_000_000) String.format("%.1fM views", viewCount / 1_000_000.0) else "$viewCount views"
                        YouTubeVideo(
                            id = vId,
                            title = item.name ?: "",
                            channelTitle = item.uploaderName ?: "",
                            channelAvatarUrl = item.uploaderAvatarUrl,
                            thumbnailUrl = item.thumbnailUrl ?: "https://i.ytimg.com/vi/$vId/hqdefault.jpg",
                            duration = durStr,
                            views = viewStr,
                            uploadDate = item.textualUploadDate ?: "Search",
                            category = "Search"
                        )
                    }
                }
            } catch (e: Exception) {
                // Handled by fallback
            }

            val finalResult = if (!onlineVideos.isNullOrEmpty()) {
                onlineVideos
            } else {
                defaultFeed.filter {
                    it.title.contains(query, ignoreCase = true) || it.channelTitle.contains(query, ignoreCase = true)
                }.ifEmpty { defaultFeed }
            }
            mainHandler.post { callback(finalResult) }
        }
    }

    var currentAvailableFormats: List<VideoStreamFormat> = emptyList()

    fun resolveStreamFormats(
        context: Context,
        videoId: String,
        callback: (bestUrl: String, allFormats: List<VideoStreamFormat>, dashUrl: String?, hlsUrl: String?) -> Unit
    ) {
        YouTubeStreamResolver.resolveStreams(videoId) { resolved ->
            if (resolved != null) {
                val formats = resolved.availableQualities.map { opt ->
                    VideoStreamFormat(
                        qualityLabel = opt.qualityLabel,
                        resolution = opt.resolution,
                        url = opt.videoUrl,
                        audioUrl = opt.audioUrl
                    )
                }
                currentAvailableFormats = formats
                callback(resolved.videoUrl, formats, null, null)
            } else {
                currentAvailableFormats = emptyList()
                callback("", emptyList(), null, null)
            }
        }
    }

    fun resolveStreamFormats(
        videoId: String,
        callback: (bestUrl: String, allFormats: List<VideoStreamFormat>, dashUrl: String?, hlsUrl: String?) -> Unit
    ) {
        YouTubeStreamResolver.resolveStreams(videoId) { resolved ->
            if (resolved != null) {
                val formats = resolved.availableQualities.map { opt ->
                    VideoStreamFormat(
                        qualityLabel = opt.qualityLabel,
                        resolution = opt.resolution,
                        url = opt.videoUrl,
                        audioUrl = opt.audioUrl
                    )
                }
                currentAvailableFormats = formats
                callback(resolved.videoUrl, formats, null, null)
            } else {
                currentAvailableFormats = emptyList()
                callback("", emptyList(), null, null)
            }
        }
    }

    fun resolveStreamFormats(
        videoId: String,
        callback: (bestUrl: String, allFormats: List<VideoStreamFormat>) -> Unit
    ) {
        resolveStreamFormats(videoId) { bestUrl, allFormats, _, _ ->
            callback(bestUrl, allFormats)
        }
    }

    fun resolveStreamUrl(videoId: String, callback: (streamUrl: String) -> Unit) {
        resolveStreamFormats(videoId) { bestUrl, _ ->
            callback(bestUrl)
        }
    }
}
