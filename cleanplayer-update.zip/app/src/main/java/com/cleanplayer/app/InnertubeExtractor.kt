package com.cleanplayer.app

/**
 * Compatibility shim for the existing settings screen.
 *
 * Stream extraction is now handled by the official NewPipe Extractor bridge.
 * These methods intentionally do not maintain a second cipher cache.
 */
object InnertubeExtractor {
    fun prefetchPlayerCipherAsync() = Unit
    fun clearCipherCache() = Unit
}