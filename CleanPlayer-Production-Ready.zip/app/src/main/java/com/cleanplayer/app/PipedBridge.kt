package com.cleanplayer.app

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.ConcurrentHashMap

/**
 * Piped Privacy Cluster Bridge
 * Dispatches requests across a live pool of decentralized Piped API instances
 * with dynamic server health checking, fast 2500ms timeout, and 5-minute failure cooldown.
 */
class PipedBridge : VideoExtractorBridge {

    override val engineId: String = "piped"
    override val displayName: String = "Piped Privacy Cluster"
    override val description: String = "Decentralized privacy proxy bypassing Google tracking"

    companion object {
        val PIPED_INSTANCES = listOf(
            "https://pipedapi.tokhmi.xyz",
            "https://api.piped.privacydev.net",
            "https://pipedapi.r4ce.nl",
            "https://api.piped.projectsegfau.lt",
            "https://piped-api.lunar.icu",
            "https://pipedapi.reallyawesomedomain.gov",
            "https://pipedapi.drgns.space",
            "https://pipedapi.ducks.party"
        )


        fun refreshInstancesAsync() {
            java.util.concurrent.Executors.newSingleThreadExecutor().execute {
                try {
                    val conn = (URL("https://piped-instances.kavin.rocks/").openConnection() as HttpURLConnection).apply {
                        connectTimeout = 3000
                        readTimeout = 3000
                    }
                    if (conn.responseCode == 200) {
                        val resp = conn.inputStream.bufferedReader().use { it.readText() }
                        val arr = org.json.JSONArray(resp)
                        val liveList = mutableListOf<String>()
                        for (i in 0 until arr.length()) {
                            val obj = arr.optJSONObject(i)
                            if (obj != null && obj.optBoolean("up", true)) {
                                val api = obj.optString("api_url")
                                if (api.isNotBlank()) liveList.add(api.trimEnd("/"))
                            }
                        }
                        if (liveList.isNotEmpty()) {
                            dynamicInstances = liveList.take(15)
                        }
                    }
                } catch (e: Exception) {}
            }
        }

        @Volatile
        var dynamicInstances: List<String> = emptyList()

        @Volatile
        private var lastWorkingInstance: String? = null
        private val failedInstances = ConcurrentHashMap<String, Long>()
        private const val COOLDOWN_MS = 5 * 60 * 1000L
    }

    override fun extract(videoId: String, authToken: String?): VideoExtractionResult? {
        val now = System.currentTimeMillis()

        // Clean up expired cooldowns
        failedInstances.entries.removeIf { now - it.value > COOLDOWN_MS }

        // Build candidate list: prioritize last working instance, then uncooled instances
        val candidateList = mutableListOf<String>()
        lastWorkingInstance?.let { last ->
            if (!failedInstances.containsKey(last)) {
                candidateList.add(last)
            }
        }
        val allSources = if (dynamicInstances.isNotEmpty()) dynamicInstances else PIPED_INSTANCES
        for (inst in allSources) {
            if (!candidateList.contains(inst) && !failedInstances.containsKey(inst)) {
                candidateList.add(inst)
            }
        }
        if (candidateList.isEmpty()) {
            candidateList.addAll(PIPED_INSTANCES)
        }

        for (instance in candidateList) {
            try {
                val endpoint = "$instance/streams/$videoId"
                val conn = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 2500
                    readTimeout = 2500
                    setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14) CleanPlayer")
                }
                if (conn.responseCode == 200) {
                    val resp = conn.inputStream.bufferedReader().use { it.readText() }
                    val json = JSONObject(resp)

                    val formatList = mutableListOf<VideoStreamFormat>()
                    val videoStreams = json.optJSONArray("videoStreams")
                    if (videoStreams != null) {
                        for (i in 0 until videoStreams.length()) {
                            val stream = videoStreams.getJSONObject(i)
                            val url = stream.optString("url")
                            val quality = stream.optString("quality", "")
                            val height = quality.replace("p", "").toIntOrNull() ?: 0

                            if (url.isNotEmpty()) {
                                formatList.add(VideoStreamFormat(quality, height, url))
                            }
                        }
                    }

                    val hlsUrl = json.optString("hls").takeIf { it.isNotBlank() }
                    val dashUrl = json.optString("dash").takeIf { it.isNotBlank() }

                    if (formatList.isNotEmpty() || !dashUrl.isNullOrEmpty() || !hlsUrl.isNullOrEmpty()) {
                        formatList.sortByDescending { it.resolution }
                        val best = formatList.firstOrNull()?.url ?: (dashUrl ?: hlsUrl ?: "")
                        val host = try { URL(instance).host } catch (e: Exception) { "piped" }

                        lastWorkingInstance = instance
                        failedInstances.remove(instance)

                        return VideoExtractionResult(
                            bestStreamUrl = best,
                            formats = formatList,
                            dashManifestUrl = dashUrl,
                            hlsManifestUrl = hlsUrl,
                            engineName = "Piped [$host]",
                            isUnthrottled = true
                        )
                    }
                } else {
                    failedInstances[instance] = now
                }
            } catch (e: Exception) {
                failedInstances[instance] = now
            }
        }
        return null
    }
}
