package com.cleanplayer.app

/**
 * Standardized bridge model for extracted video streaming formats.
 */
data class VideoExtractionResult(
    val bestStreamUrl: String,
    val formats: List<VideoStreamFormat>,
    val dashManifestUrl: String? = null,
    val hlsManifestUrl: String? = null,
    val engineName: String,
    val isUnthrottled: Boolean = true
)

/**
 * Common Extractor Interface for all YouTube playback and streaming engines.
 */
interface VideoExtractorBridge {
    val engineId: String
    val displayName: String
    val description: String

    fun extract(videoId: String, authToken: String? = null): VideoExtractionResult?
}
