package com.cleanplayer.app

import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import androidx.media3.ui.PlayerView

/**
 * AndroidX Media3 (ExoPlayer) Dedicated Adaptive Engine for YouTube
 * Thread-safe, synchronized playback manager with null-safety and robust lifecycle controls.
 */
object YouTubeExoPlayerManager {

    var exoPlayer: ExoPlayer? = null
        private set

    var currentPlayingVideo: YouTubeVideo? = null
        private set

    var currentStreamUrl: String? = null
        private set

    var currentQualityLabel: String = "Auto"
        private set

    private var trackSelector: DefaultTrackSelector? = null
    private val mainHandler = Handler(Looper.getMainLooper())
    private var sponsorCheckRunnable: Runnable? = null
    private val playerLock = Any()

    var onSponsorSkipped: ((category: String) -> Unit)? = null
    var onPlaybackStateChanged: ((isPlaying: Boolean) -> Unit)? = null
    var onBufferingStateChanged: ((isBuffering: Boolean) -> Unit)? = null
    var onPlayerError: ((error: PlaybackException) -> Unit)? = null
    var onAudioSessionIdChanged: ((sessionId: Int) -> Unit)? = null

    @Volatile
    private var wasPlayingBeforeNetworkLoss = false
    private var isNetworkRecoveryRegistered = false

    private fun registerNetworkRecovery(context: Context) {
        if (isNetworkRecoveryRegistered) return
        NetworkMonitor.register(context)
        NetworkMonitor.addListener { isConnected ->
            val player = exoPlayer ?: return@addListener
            if (!isConnected) {
                // Connection dropped: record playback state and gracefully pause to avoid error crash
                if (player.isPlaying) {
                    wasPlayingBeforeNetworkLoss = true
                    player.pause()
                }
            } else {
                // Connection restored: auto-resume playback smoothly
                if (wasPlayingBeforeNetworkLoss) {
                    wasPlayingBeforeNetworkLoss = false
                    if (player.playbackState == Player.STATE_IDLE) {
                        player.prepare()
                    }
                    player.play()
                }
            }
        }
        isNetworkRecoveryRegistered = true
    }

    @Volatile
    private var exoSimpleCache: androidx.media3.datasource.cache.SimpleCache? = null

    @Synchronized
    fun getCache(context: Context): androidx.media3.datasource.cache.SimpleCache {
        val existing = exoSimpleCache
        if (existing != null) return existing

        val cacheDir = java.io.File(context.applicationContext.cacheDir, "cleanplayer_exo_lru_cache")
        val evictor = androidx.media3.datasource.cache.LeastRecentlyUsedCacheEvictor(100 * 1024 * 1024L)
        val databaseProvider = androidx.media3.database.StandaloneDatabaseProvider(context.applicationContext)
        val newCache = androidx.media3.datasource.cache.SimpleCache(cacheDir, evictor, databaseProvider)
        exoSimpleCache = newCache
        return newCache
    }

    @Synchronized
    fun getOrCreatePlayer(context: Context): ExoPlayer {
        val existing = exoPlayer
        if (existing != null) return existing

        val appContext = context.applicationContext
        val selector = DefaultTrackSelector(appContext)
        trackSelector = selector

        val httpDataSourceFactory = DefaultHttpDataSource.Factory()
            .setUserAgent("Mozilla/5.0 (Linux; Android 14; Mobile; rv:124.0) Gecko/124.0 Firefox/124.0")
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(15000)
            .setReadTimeoutMs(15000)

        val cacheFactory = try {
            val cache = getCache(appContext)
            androidx.media3.datasource.cache.CacheDataSource.Factory()
                .setCache(cache)
                .setUpstreamDataSourceFactory(httpDataSourceFactory)
                .setFlags(androidx.media3.datasource.cache.CacheDataSource.FLAG_IGNORE_CACHE_ON_ERROR)
        } catch (e: Exception) {
            null
        }

        val upstreamFactory = cacheFactory ?: httpDataSourceFactory
        val dataSourceFactory = DefaultDataSource.Factory(appContext, upstreamFactory)
        val mediaSourceFactory = DefaultMediaSourceFactory(dataSourceFactory)

        val loadControl = DefaultLoadControl.Builder()
            .setBufferDurationsMs(
                DefaultLoadControl.DEFAULT_MIN_BUFFER_MS,
                DefaultLoadControl.DEFAULT_MAX_BUFFER_MS,
                1500, // min buffer for playback
                2500  // min buffer for playback after rebuffer
            )
            .build()

        val audioAttributes = AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA)
            .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
            .build()

        val player = ExoPlayer.Builder(appContext)
            .setMediaSourceFactory(mediaSourceFactory)
            .setTrackSelector(selector)
            .setLoadControl(loadControl)
            .setAudioAttributes(audioAttributes, true)
            .setHandleAudioBecomingNoisy(true)
            .build()

        player.addListener(object : Player.Listener {
            override fun onAudioSessionIdChanged(audioSessionId: Int) {
                if (audioSessionId > 0) {
                    onAudioSessionIdChanged?.invoke(audioSessionId)
                }
            }
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                onPlaybackStateChanged?.invoke(isPlaying)
                if (isPlaying) {
                    startSponsorCheckLoop()
                } else {
                    stopSponsorCheckLoop()
                }
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                when (playbackState) {
                    Player.STATE_BUFFERING -> {
                        onBufferingStateChanged?.invoke(true)
                    }
                    Player.STATE_READY -> {
                        onBufferingStateChanged?.invoke(false)
                    }
                    Player.STATE_ENDED -> {
                        stopSponsorCheckLoop()
                        onBufferingStateChanged?.invoke(false)
                        onPlaybackStateChanged?.invoke(false)
                    }
                    Player.STATE_IDLE -> {
                        onBufferingStateChanged?.invoke(false)
                    }
                }
            }

            override fun onPlayerError(error: PlaybackException) {
                error.printStackTrace()
                onBufferingStateChanged?.invoke(false)
                onPlaybackStateChanged?.invoke(false)
                onPlayerError?.invoke(error)

                // Automatic fallback to secondary or direct format if available
                tryAlternativeFormat(appContext)
            }
        })

        registerNetworkRecovery(appContext)
        exoPlayer = player
        return player
    }

    private fun tryAlternativeFormat(context: Context) {
        val curUrl = currentStreamUrl ?: return
        val video = currentPlayingVideo ?: return
        val available = YouTubeFeedRepository.currentAvailableFormats
        val nextFormat = available.firstOrNull { it.url != curUrl && it.url.isNotBlank() }
        if (nextFormat != null) {
            mainHandler.post {
                playVideo(
                    context = context,
                    video = video,
                    streamUrl = nextFormat.url,
                    isDash = nextFormat.url.contains(".mpd"),
                    isHls = nextFormat.url.contains(".m3u8")
                )
            }
        }
    }

    @Synchronized
    fun playVideo(
        context: Context,
        video: YouTubeVideo,
        streamUrl: String,
        isDash: Boolean = false,
        isHls: Boolean = false,
        startPosMs: Long = 0L
    ) {
        val player = getOrCreatePlayer(context)

        // If same video and URL are already loaded, just seek if needed
        if (currentPlayingVideo?.id == video.id && currentStreamUrl == streamUrl) {
            try {
                if (startPosMs > 0L) player.seekTo(startPosMs)
                player.play()
            } catch (e: Exception) {}
            return
        }

        currentPlayingVideo = video
        currentStreamUrl = streamUrl

        val mimeType = when {
            isDash || streamUrl.contains(".mpd") -> MimeTypes.APPLICATION_MPD
            isHls || streamUrl.contains(".m3u8") -> MimeTypes.APPLICATION_M3U8
            streamUrl.contains(".webm") -> MimeTypes.VIDEO_WEBM
            streamUrl.contains(".mp4") -> MimeTypes.VIDEO_MP4
            else -> null // Let Media3 auto-sniff container format
        }

        val metadata = MediaMetadata.Builder()
            .setTitle(video.title)
            .setArtist(video.channelTitle)
            .setArtworkUri(Uri.parse(video.thumbnailUrl))
            .build()

        val mediaItemBuilder = MediaItem.Builder()
            .setUri(Uri.parse(streamUrl))
            .setMediaMetadata(metadata)

        if (mimeType != null) {
            mediaItemBuilder.setMimeType(mimeType)
        }

        val mediaItem = mediaItemBuilder.build()

        // Fetch SponsorBlock segments for this video
        SponsorBlockManager.fetchSegments(video.id)

        try {
            onBufferingStateChanged?.invoke(true)
            player.setMediaItem(mediaItem)
            player.prepare()
            if (startPosMs > 0L) {
                player.seekTo(startPosMs)
            }
            player.playWhenReady = true
            player.play()
            if (PlayerHolder.backgroundPipMode > 0) {
                MediaPlaybackService.start(
                    context = context,
                    title = video.title,
                    artist = video.channelTitle,
                    isPlaying = true,
                    isYouTube = true,
                    thumbUrl = video.thumbnailUrl
                )
            }
        } catch (e: Exception) {
            e.printStackTrace()
            onBufferingStateChanged?.invoke(false)
        }
    }

    fun attachPlayerView(playerView: PlayerView) {
        val player = getOrCreatePlayer(playerView.context)
        if (playerView.player != player) {
            playerView.player = player
        }
    }

    fun detachPlayerView(playerView: PlayerView) {
        if (playerView.player == exoPlayer) {
            playerView.player = null
        }
    }

    fun togglePlayPause() {
        val player = exoPlayer ?: return
        try {
            if (player.isPlaying) {
                player.pause()
            } else {
                player.play()
            }
        } catch (e: Exception) {}
    }

    fun pause() {
        try {
            exoPlayer?.pause()
        } catch (e: Exception) {}
    }

    fun play() {
        try {
            exoPlayer?.play()
        } catch (e: Exception) {}
    }

    fun seekTo(posMs: Long) {
        try {
            exoPlayer?.seekTo(posMs)
        } catch (e: Exception) {}
    }

    fun setPlaybackSpeed(speed: Float) {
        try {
            exoPlayer?.playbackParameters = PlaybackParameters(speed)
        } catch (e: Exception) {}
    }

    fun setVideoQuality(maxHeight: Int) {
        val selector = trackSelector ?: return
        try {
            if (maxHeight <= 0) {
                selector.parameters = selector.buildUponParameters()
                    .clearVideoSizeConstraints()
                    .build()
                currentQualityLabel = "Auto"
            } else {
                selector.parameters = selector.buildUponParameters()
                    .setMaxVideoSize(3840, maxHeight)
                    .build()
                currentQualityLabel = "${maxHeight}p"
            }
        } catch (e: Exception) {}
    }

    @Synchronized
    private fun startSponsorCheckLoop() {
        stopSponsorCheckLoop()
        val runnable = object : Runnable {
            override fun run() {
                synchronized(playerLock) {
                    val player = exoPlayer
                    if (player != null && player.playbackState != Player.STATE_IDLE && player.playbackState != Player.STATE_ENDED) {
                        try {
                            if (player.isPlaying) {
                                val currentPos = player.currentPosition
                                val skip = SponsorBlockManager.checkSkip(currentPos)
                                if (skip != null) {
                                    player.seekTo(skip.first)
                                    onSponsorSkipped?.invoke(skip.second)
                                }
                            }
                        } catch (e: Exception) {
                            // Suppress transient player position exceptions
                        }
                        mainHandler.postDelayed(this, 250)
                    }
                }
            }
        }
        sponsorCheckRunnable = runnable
        mainHandler.postDelayed(runnable, 250)
    }

    @Synchronized
    private fun stopSponsorCheckLoop() {
        sponsorCheckRunnable?.let {
            mainHandler.removeCallbacks(it)
            sponsorCheckRunnable = null
        }
    }

    @Synchronized
    fun release() {
        stopSponsorCheckLoop()
        synchronized(playerLock) {
            try {
                exoPlayer?.stop()
                exoPlayer?.release()
            } catch (e: Exception) {}
            exoPlayer = null
            trackSelector = null
            currentPlayingVideo = null
            currentStreamUrl = null
            onPlaybackStateChanged = null
            onBufferingStateChanged = null
            onSponsorSkipped = null
            onPlayerError = null
        }
    }
}
