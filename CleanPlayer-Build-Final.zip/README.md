# Multimedia (Universal Clean Media Player for Android)

High-performance, Lightweight, Zero-Ads, Zero-Tracking Android Media Player with Multimedia-style Playback Controls, Modern Homescreen and Categorized Settings Menu.

## Features
- **Advanced Video Playback Interface:**
  - **HW / SW Decoder Toggle Button:** Instant on-screen hardware acceleration toggle (MediaCodec HW vs. CPU FFmpeg SW).
  - **Screen Lock Feature (🔒):** Tap lock to freeze controls and avoid accidental touches during movies; tap floating unlock to resume.
  - **Quick Seek Controls:** Dedicated -10s rewind and +10s forward buttons plus full-width progress slider.
  - **Dual-Side Touch Gestures:** Vertical swipe on left for Brightness, vertical swipe on right for Volume, and horizontal swipe for fast seek with center time card.
  - **Aspect Ratio Selector (⛶):** Instant switching between Best Fit, 16:9, 4:3, and Fill.
  - **Spatial Audio Virtualizer:** 3D Headphone, Cinema 3D, and Wide Soundstage acoustic room effects.
  - **Background Playback (BG):** Optional background audio playback with lock screen media notifications.
- **Universal Codec & Container Support:**
  - Plays MKV, MP4, WebM, AVI, TS, 10-bit HEVC, and multi-channel audio tracks.
  - Automatic fallback from Hardware decoding to Software CPU decoding if any file format is not supported by device hardware.
- **Homescreen & Library:**
  - Bottom Navigation with **Video**, **Audio**, and **Settings** tabs.
  - Automatic local media discovery (scans storage for video and audio tracks).
  - Open File button for direct storage browsing.
- **About Multimedia:**
  - App Version: **2.0**
  - Lead Developer: **Rajesh Shah**
  - Zero Ads & Zero Bloatware.

## How to Build on GitHub Actions
1. Upload `multimedia-player.zip` to your GitHub repository.
2. Go to the **Actions** tab in GitHub.
3. The `Build APK` workflow will run automatically.
4. Download the compiled `Multimedia-debug.apk` from the **Artifacts** section.
