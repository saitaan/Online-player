package com.cleanplayer.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "watch_history")
data class WatchHistoryEntity(
    @PrimaryKey val id: String,
    val title: String,
    val channelTitle: String,
    val channelAvatarUrl: String?,
    val thumbnailUrl: String,
    val duration: String,
    val views: String,
    val uploadDate: String,
    val category: String,
    val watchedAt: Long = System.currentTimeMillis()
)
