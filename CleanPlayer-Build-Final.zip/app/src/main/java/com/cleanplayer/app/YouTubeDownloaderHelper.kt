package com.cleanplayer.app

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Environment
import android.widget.Toast
import java.io.File

object YouTubeDownloaderHelper {

    fun downloadVideo(context: Context, video: YouTubeVideo) {
        Toast.makeText(context, "Fetching clean download link for '${video.title}'...", Toast.LENGTH_SHORT).show()

        YouTubeFeedRepository.resolveStreamUrl(video.id) { streamUrl ->
            if (streamUrl.isBlank()) {
                android.os.Handler(android.os.Looper.getMainLooper()).post {
                    Toast.makeText(context, "Download failed: stream extraction failed or video is restricted.", Toast.LENGTH_LONG).show()
                }
                return@resolveStreamUrl
            }
            try {
                val cleanFileName = sanitizeFileName("${video.title}.mp4")
                val request = DownloadManager.Request(Uri.parse(streamUrl)).apply {
                    setTitle(video.title)
                    setDescription("Downloading via CleanPlayer...")
                    setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                    setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "CleanPlayer/$cleanFileName")
                    setAllowedOverMetered(true)
                    setAllowedOverRoaming(true)
                }

                val downloadManager = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
                downloadManager.enqueue(request)

                android.os.Handler(android.os.Looper.getMainLooper()).post {
                    Toast.makeText(
                        context,
                        "Download started! File will be saved to Downloads/CleanPlayer",
                        Toast.LENGTH_LONG
                    ).show()
                }
            } catch (e: Exception) {
                android.os.Handler(android.os.Looper.getMainLooper()).post {
                    Toast.makeText(context, "Download failed: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun sanitizeFileName(name: String): String {
        return name.replace(Regex("[\\\\/:*?\"<>|]"), "_")
    }
}
