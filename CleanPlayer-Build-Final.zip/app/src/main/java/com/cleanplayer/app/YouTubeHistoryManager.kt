package com.cleanplayer.app

import android.content.Context
import com.cleanplayer.app.data.AppDatabase
import com.cleanplayer.app.data.FavoriteEntity
import com.cleanplayer.app.data.WatchHistoryEntity
import java.util.concurrent.Executors

object YouTubeHistoryManager {

    private val executor = Executors.newSingleThreadExecutor()

    fun addWatchHistory(context: Context, video: YouTubeVideo) {
        executor.execute {
            try {
                val db = AppDatabase.getDatabase(context)
                val entity = WatchHistoryEntity(
                    id = video.id,
                    title = video.title,
                    channelTitle = video.channelTitle,
                    channelAvatarUrl = video.channelAvatarUrl,
                    thumbnailUrl = video.thumbnailUrl,
                    duration = video.duration,
                    views = video.views,
                    uploadDate = video.uploadDate,
                    category = video.category,
                    watchedAt = System.currentTimeMillis()
                )
                db.watchHistoryDao().insertHistory(entity)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun getWatchHistory(context: Context): List<YouTubeVideo> {
        return try {
            val db = AppDatabase.getDatabase(context)
            val list = db.watchHistoryDao().getAllHistory()
            list.map { entity ->
                YouTubeVideo(
                    id = entity.id,
                    title = entity.title,
                    channelTitle = entity.channelTitle,
                    channelAvatarUrl = entity.channelAvatarUrl,
                    thumbnailUrl = entity.thumbnailUrl,
                    duration = entity.duration,
                    views = entity.views,
                    uploadDate = entity.uploadDate,
                    category = entity.category
                )
            }
        } catch (e: Exception) {
            e.printStackTrace()
            emptyList()
        }
    }

    fun clearHistory(context: Context) {
        executor.execute {
            try {
                AppDatabase.getDatabase(context).watchHistoryDao().clearAllHistory()
            } catch (e: Exception) {}
        }
    }

    fun toggleBookmark(context: Context, video: YouTubeVideo): Boolean {
        return try {
            val db = AppDatabase.getDatabase(context)
            val isFav = db.favoriteDao().isFavorite(video.id)
            if (isFav) {
                db.favoriteDao().removeFavorite(video.id)
                false
            } else {
                db.favoriteDao().addFavorite(
                    FavoriteEntity(
                        uri = video.id,
                        title = video.title,
                        artist = video.channelTitle,
                        isVideo = true,
                        addedAt = System.currentTimeMillis()
                    )
                )
                true
            }
        } catch (e: Exception) {
            false
        }
    }

    fun isBookmarked(context: Context, videoId: String): Boolean {
        return try {
            AppDatabase.getDatabase(context).favoriteDao().isFavorite(videoId)
        } catch (e: Exception) {
            false
        }
    }

    fun getBookmarks(context: Context): List<YouTubeVideo> {
        return try {
            val db = AppDatabase.getDatabase(context)
            val favs = db.favoriteDao().getAllFavorites()
            favs.map { f ->
                YouTubeVideo(
                    id = f.uri,
                    title = f.title,
                    channelTitle = f.artist,
                    thumbnailUrl = "https://i.ytimg.com/vi/${f.uri}/hqdefault.jpg",
                    duration = "00:00",
                    views = "Saved",
                    uploadDate = "Favorites",
                    category = "Favorites"
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }
}
