package com.cleanplayer.app

import android.content.Context
import android.net.Uri

object AudioTagManager {
    private const val PREFS_NAME = "cleanplayer_audio_tag_overrides"

    fun getKey(uri: Uri?, path: String?): String {
        return path?.takeIf { it.isNotBlank() } ?: uri?.toString() ?: "default_audio_key"
    }

    fun saveTags(context: Context, key: String, title: String, artist: String, album: String) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit()
            .putString("${key}_title", title.trim())
            .putString("${key}_artist", artist.trim())
            .putString("${key}_album", album.trim())
            .apply()
    }

    fun getTitle(context: Context, key: String, fallback: String): String {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getString("${key}_title", null) ?: fallback
    }

    fun getArtist(context: Context, key: String, fallback: String): String {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getString("${key}_artist", null) ?: fallback
    }

    fun getAlbum(context: Context, key: String, fallback: String?): String? {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getString("${key}_album", null) ?: fallback
    }
}
