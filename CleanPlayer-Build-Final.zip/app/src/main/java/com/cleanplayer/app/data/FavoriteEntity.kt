package com.cleanplayer.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "favorites")
data class FavoriteEntity(
    @PrimaryKey val uri: String,
    val title: String,
    val artist: String,
    val isVideo: Boolean,
    val addedAt: Long = System.currentTimeMillis()
)
