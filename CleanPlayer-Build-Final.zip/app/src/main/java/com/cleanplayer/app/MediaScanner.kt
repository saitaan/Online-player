package com.cleanplayer.app

import android.content.ContentUris
import android.content.Context
import android.provider.MediaStore
import java.io.File

object MediaScanner {

    fun scanVideos(context: Context): List<MediaItem> {
        val items = ArrayList<MediaItem>()
        val projection = arrayOf(
            MediaStore.Video.Media._ID,
            MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.Media.DURATION,
            MediaStore.Video.Media.SIZE,
            MediaStore.Video.Media.DATA,
            MediaStore.Video.Media.BUCKET_DISPLAY_NAME
        )
        val sortOrder = "${MediaStore.Video.Media.DATE_ADDED} DESC"

        try {
            context.contentResolver.query(
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                projection,
                null,
                null,
                sortOrder
            )?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
                val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
                val durationCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
                val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE)
                val dataCol = cursor.getColumnIndex(MediaStore.Video.Media.DATA)
                val bucketCol = cursor.getColumnIndex(MediaStore.Video.Media.BUCKET_DISPLAY_NAME)

                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idCol)
                    val name = cursor.getString(nameCol) ?: "Video $id"
                    val duration = cursor.getLong(durationCol)
                    val size = cursor.getLong(sizeCol)
                    val filePath = if (dataCol != -1) cursor.getString(dataCol) else null
                    val bucketName = if (bucketCol != -1) cursor.getString(bucketCol) else null

                    val folderName = when {
                        !bucketName.isNullOrBlank() -> bucketName
                        !filePath.isNullOrBlank() -> {
                            val parent = File(filePath).parentFile?.name
                            if (!parent.isNullOrBlank()) parent else "Videos"
                        }
                        else -> "Videos"
                    }

                    val folderPath = if (!filePath.isNullOrBlank()) {
                        File(filePath).parent ?: ""
                    } else ""

                    val contentUri = ContentUris.withAppendedId(
                        MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                        id
                    )
                    items.add(
                        MediaItem(
                            id = id,
                            uri = contentUri,
                            title = name,
                            durationMs = duration,
                            sizeBytes = size,
                            isVideo = true,
                            filePath = filePath,
                            folderName = folderName,
                            folderPath = folderPath
                        )
                    )
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return items
    }

    fun cleanMediaTitle(raw: String): String {
        var s = raw.trim()
        val exts = listOf(".mp3", ".m4a", ".wav", ".aac", ".flac", ".opus", ".ogg", ".mp4", ".mkv", ".webm", ".3gp", ".avi")
        for (ext in exts) {
            if (s.endsWith(ext, ignoreCase = true)) {
                s = s.substring(0, s.length - ext.length)
                break
            }
        }
        return s.trim()
    }

    fun scanAudio(context: Context): List<MediaItem> {
        val items = ArrayList<MediaItem>()
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.DISPLAY_NAME,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.SIZE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.DATA
        )
        val sortOrder = "${MediaStore.Audio.Media.DATE_ADDED} DESC"

        try {
            context.contentResolver.query(
                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                projection,
                null,
                null,
                sortOrder
            )?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val titleCol = cursor.getColumnIndex(MediaStore.Audio.Media.TITLE)
                val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DISPLAY_NAME)
                val durationCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
                val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.SIZE)
                val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                val albumCol = cursor.getColumnIndex(MediaStore.Audio.Media.ALBUM)
                val dataCol = cursor.getColumnIndex(MediaStore.Audio.Media.DATA)

                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idCol)
                    val rawTitle = if (titleCol != -1) cursor.getString(titleCol) else null
                    val rawName = cursor.getString(nameCol) ?: "Audio $id"
                    val duration = cursor.getLong(durationCol)
                    val size = cursor.getLong(sizeCol)
                    val rawArtist = cursor.getString(artistCol)
                    val rawAlbum = if (albumCol != -1) cursor.getString(albumCol) else null
                    val filePath = if (dataCol != -1) cursor.getString(dataCol) else null

                    val artist = when {
                        !rawArtist.isNullOrBlank() && rawArtist != "<unknown>" -> rawArtist.trim()
                        else -> "Unknown artist"
                    }
                    val album = when {
                        !rawAlbum.isNullOrBlank() && rawAlbum != "<unknown>" -> rawAlbum.trim()
                        else -> null
                    }

                    val titleCandidate = when {
                        !rawTitle.isNullOrBlank() && !rawTitle.all { it.isDigit() } -> cleanMediaTitle(rawTitle)
                        !rawName.isNullOrBlank() && !rawName.substringBeforeLast(".").all { it.isDigit() } -> cleanMediaTitle(rawName)
                        !rawTitle.isNullOrBlank() -> cleanMediaTitle(rawTitle)
                        else -> cleanMediaTitle(rawName)
                    }

                    val fileTitle = if (!filePath.isNullOrBlank()) {
                        val f = File(filePath)
                        val nameNoExt = f.name.substringBeforeLast('.')
                        if (nameNoExt.isNotBlank() && !nameNoExt.all { it.isDigit() }) {
                            cleanMediaTitle(nameNoExt)
                        } else null
                    } else null

                    val finalTitle = when {
                        !titleCandidate.all { it.isDigit() } -> titleCandidate
                        !fileTitle.isNullOrBlank() -> fileTitle
                        !album.isNullOrBlank() -> album
                        else -> titleCandidate
                    }

                    val folderName = if (!filePath.isNullOrBlank()) {
                        File(filePath).parentFile?.name ?: "Music"
                    } else "Music"
                    val folderPath = if (!filePath.isNullOrBlank()) {
                        File(filePath).parent ?: ""
                    } else ""

                    val contentUri = ContentUris.withAppendedId(
                        MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                        id
                    )
                    items.add(
                        MediaItem(
                            id = id,
                            uri = contentUri,
                            title = finalTitle,
                            durationMs = duration,
                            sizeBytes = size,
                            isVideo = false,
                            artist = artist,
                            filePath = filePath,
                            folderName = folderName,
                            folderPath = folderPath
                        )
                    )
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return items
    }
}
