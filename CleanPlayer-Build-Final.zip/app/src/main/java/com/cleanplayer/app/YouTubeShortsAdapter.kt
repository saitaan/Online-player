package com.cleanplayer.app

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class YouTubeShortsAdapter(
    private val context: Context,
    private var items: List<YouTubeVideo>,
    private val onItemClick: (YouTubeVideo) -> Unit
) : RecyclerView.Adapter<YouTubeShortsAdapter.ShortsViewHolder>() {

    fun updateItems(newItems: List<YouTubeVideo>) {
        this.items = newItems
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ShortsViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_youtube_shorts, parent, false)
        return ShortsViewHolder(view)
    }

    override fun onBindViewHolder(holder: ShortsViewHolder, position: Int) {
        val item = items[position]
        holder.tvTitle.text = item.title
        holder.tvViews.text = item.views
        ImageLoaderHelper.loadImage(item.thumbnailUrl, holder.ivThumbnail, R.drawable.ic_video)

        holder.itemView.setOnClickListener {
            onItemClick(item)
        }
    }

    override fun getItemCount(): Int = items.size

    class ShortsViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val ivThumbnail: ImageView = itemView.findViewById(R.id.ivShortsThumbnail)
        val tvTitle: TextView = itemView.findViewById(R.id.tvShortsTitle)
        val tvViews: TextView = itemView.findViewById(R.id.tvShortsViews)
    }
}
